package J04008;
import java.util.Scanner;
public class Main
{
    public static void main(String[] args)
    {
        Scanner in = new Scanner(System.in);
        int t = in.nextInt();
        while(t-->0)
        {
            Point a = new Point(in.nextDouble(),in.nextDouble());
            Point b = new Point(in.nextDouble(),in.nextDouble());
            Point c = new Point(in.nextDouble(),in.nextDouble());
            check(a,b,c);
        }
    }
    static double dis(Point a,Point b)
    {
        return Math.sqrt((a.getX()-b.getX())*(a.getX()-b.getX())+(a.getY()-b.getY())*(a.getY()-b.getY()));
    }
    static void check(Point a,Point b,Point c)
    {
        double dis1 = dis(a,b);
        double dis2 = dis(a,c);
        double dis3 = dis(b,c);
        double  m = Math.max(dis3,Math.max(dis1,dis2));
        if(m*2 >= (dis1+dis2 +dis3))
        {
            System.out.println("INVALID");
            return;
        }
        Double tron = dis1+dis2 + dis3;
        tron = Math.round(tron*1000.0)/1000.0;
        System.out.println(tron);
    }
}
