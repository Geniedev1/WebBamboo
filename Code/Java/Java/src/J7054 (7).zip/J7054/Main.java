package J7054;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;
import java.io.File;
public class Main {
    public static void main(String[] args) throws IOException, FileNotFoundException
    {
       Scanner in = new Scanner(new File("BANGDIEM.in"));
       ArrayList<Table> ts = new ArrayList<>();
       int t = Integer.parseInt(in.nextLine());
       for(int i =1 ;i<= t;i++)
       {
           ts.add(new Table(in.nextLine(),Integer.parseInt(in.nextLine()),Integer.parseInt(in.nextLine()),Integer.parseInt(in.nextLine()),i));
       }
       Collections.sort(ts);
       int rank = 1;
       for (int i = 0;i<t;i++)
       {
           if(i>0 && ts.get(i).getSumpoint().equals( ts.get(i-1).getSumpoint())) {
               ts.get(i).setStatus(ts.get(i-1).getStatus());
               rank ++;
           }
           else
           {
               ts.get(i).setStatus(rank);
               rank ++;
           }
       }
       for(Table b : ts)
       {
           System.out.println(b);
       }
    }
}
