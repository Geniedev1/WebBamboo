package Th2;

import java.text.ParseException;
import java.time.Duration;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;

public class Company implements Comparable<Company> {
    private String id,name;
    private LocalTime vao,ra;
    private long time;
    public Company(String id,String name,String vao,String ra) throws ParseException
    {
        DateTimeFormatter fm = DateTimeFormatter.ofPattern("HH:mm");
        this.vao = LocalTime.parse(vao);
        this.ra = LocalTime.parse(ra);
        this.id = id;
        this.name = name;
        setTime();
    }
    private void setTime()
    {
        Duration dr = Duration.between(vao,ra);
        time = dr.toMinutes() -60;
    }
    public long getTime()
    {
        return time;
    }
    public int compareTo(Company o)
    {
        return Long.compare(o.time,time);
    }
    public String toString()
    {
        long h = time / 60;
        long m = time % 60;
        return id + " " + name + " " + h + " gio " + m + " phut " ;
    }
}
