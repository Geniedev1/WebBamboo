package Th2;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) throws IOException, ParseException, FileNotFoundException
    {
        Scanner in = new Scanner(System.in);
        ArrayList<Company> cp = new ArrayList<>();
        int t = Integer.parseInt(in.nextLine());
        while(t-->0)
        {
            cp.add(new Company(in.nextLine(),in.nextLine(),in.nextLine(),in.nextLine()));
        }
        Collections.sort(cp);
        for (Company c : cp)
        {
            if(c.getTime() >= 480)
            {
                System.out.println(c + " DU");
            }
            else
            {
                System.out.println(c+ " THIEU");
            }
        }
    }
}
