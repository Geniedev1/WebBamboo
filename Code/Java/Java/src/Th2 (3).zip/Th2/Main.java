package Th2;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int numWorkers = Integer.parseInt(scanner.nextLine());
        List<Worker> workers = new ArrayList<>();

        for (int i = 0; i < numWorkers; i++) {
            String id = scanner.nextLine();
            String name = scanner.nextLine();
            String arrival = scanner.nextLine();
            String departure = scanner.nextLine();
            workers.add(new Worker(id, name, arrival, departure));
        }

        Collections.sort(workers);

        for (Worker worker : workers) {
            System.out.println(worker);
        }

        scanner.close();
    }
}
