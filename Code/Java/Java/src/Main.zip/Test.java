public class Test
{
    static class Test1
    {
        int a,b;
    }
    public static void main(String[] args)
    {
        Test1 t = new Test1();
        t.a = 1;
        t.b = 1;
        System.out.println(t.a+t.b);
    }
}
