package bai9p2;

public class Instit {
    private String institute,name;
    public Instit(String institute, String name) {
        this.institute = institute;
        this.name = name;
    }
    public String getname() {
        return name;
    }
}
