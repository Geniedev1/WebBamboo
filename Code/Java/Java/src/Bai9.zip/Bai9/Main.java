package Bai9;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) throws IOException, FileNotFoundException {
        Scanner sc = new Scanner(System.in);
        List<Sinhvien> list = new ArrayList<Sinhvien>();
        int n = sc.nextInt();
        while (sc.hasNextLine()) {
            list.add(new Sinhvien(sc.nextLine(),sc.nextInt(),sc.nextInt()));
        }
        Collections.sort(list);
        for(Sinhvien sinhvien : list) {
            System.out.println(sinhvien);
        }
    }
}
