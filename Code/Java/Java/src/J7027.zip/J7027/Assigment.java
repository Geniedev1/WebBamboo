package J7027;

public class Assigment {
    private String topic;
    public Assigment(String topic)
    {
        this.topic = topic;
    }
   public String toString()
   {
       return topic;
   }
}
