package J6003;

public class Student {
    private String id,name,phone;
    private int stt;
    public Student(String id,String name,String phone,int stt)
    {
        this.id = id;
        this.name = name;
        this.phone = phone;
        this.stt = stt;
    }
    public int getStt()
    {
        return stt;
    }
    public String toString()
    {
        return id + " " + name + " " + phone;
    }
}

