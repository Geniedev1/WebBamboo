import  {Header } from '../Component/Header';
import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { Footer } from "../Component/Footer";
export const Payment = () => {
      useEffect(() => { window.scrollTo(0, 0) }, []);
    return (
        <>
            <Header />
             <div className = "p-10">
                <div>

                </div>
             </div>
            <Footer />
        </>
    );
};